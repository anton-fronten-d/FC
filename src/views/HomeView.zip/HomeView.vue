<template>
  <div class="app">
    <!-- Navigation -->
    <nav class="navbar">
      <div class="nav-container">
        <!-- Logo -->
        <div class="nav-logo" @click="currentView = 'home'">
          <div class="logo-icon">R</div>
          <span class="logo-text">REMATCH FC</span>
        </div>

        <!-- Navigation Links -->
        <div class="nav-links" :class="{ 'nav-open': mobileMenuOpen }">
          <button
            v-for="item in navItems"
            :key="item.id"
            @click="navigateTo(item.id)"
            :class="['nav-link', { active: currentView === item.id }]"
          >
            {{ item.name }}
          </button>
        </div>

        <!-- Mobile Menu Button -->
        <button @click="mobileMenuOpen = !mobileMenuOpen" class="mobile-menu-btn">☰</button>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
      <!-- Home Page -->
      <div v-if="currentView === 'home'" class="page home-page">
        <div class="hero-section">
          <h1 class="hero-title">REMATCH FC</h1>
          <div class="hero-line"></div>
          <p class="hero-subtitle">Выберите игрока для просмотра детальной информации</p>
        </div>

        <div class="players-grid">
          <div
            v-for="player in players"
            :key="player.id"
            @click="selectPlayer(player)"
            class="player-card"
          >
            <div class="player-image">
              <div class="player-avatar">⚽</div>
              <div class="player-rating">{{ player.rating }}</div>
            </div>

            <div class="player-info">
              <h3 class="player-name">{{ player.name }}</h3>
              <p class="player-position">{{ player.position }}</p>
              <div class="player-stats">
                <span>Возраст: {{ player.age }}</span>
                <span>№{{ player.number }}</span>
              </div>
            </div>

            <div class="card-glow"></div>
          </div>
        </div>
      </div>

      <!-- About Page -->
      <div v-if="currentView === 'about'" class="page about-page">
        <div class="page-header">
          <h1 class="page-title">О НАС</h1>
          <div class="page-line"></div>
          <p class="page-subtitle">Познакомьтесь с легендами REMATCH FC</p>
        </div>

        <div class="biography-section">
          <div v-for="player in players" :key="player.id" class="biography-card">
            <div class="bio-avatar">
              <div class="bio-image">⚽</div>
              <div class="bio-rating">{{ player.rating }}</div>
            </div>

            <div class="bio-content">
              <h2 class="bio-name">{{ player.name }}</h2>
              <p class="bio-position">{{ player.position }} • №{{ player.number }}</p>
              <p class="bio-text">{{ player.biography }}</p>

              <div class="bio-stats">
                <div class="stat-item">
                  <span class="stat-label">ВОЗРАСТ</span>
                  <span class="stat-value">{{ player.age }}</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">ГОЛЫ</span>
                  <span class="stat-value">{{ player.goals }}</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">МАТЧИ</span>
                  <span class="stat-value">{{ player.matches }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Awards Page -->
      <div v-if="currentView === 'awards'" class="page awards-page">
        <div class="page-header">
          <h1 class="page-title awards-title">НАШИ НАГРАДЫ</h1>
          <div class="page-line awards-line"></div>
          <p class="page-subtitle">Трофеи и достижения REMATCH FC</p>
        </div>

        <div class="awards-grid">
          <div v-for="award in awards" :key="award.id" class="award-card">
            <div class="award-icon">{{ award.icon }}</div>
            <h3 class="award-title">{{ award.title }}</h3>
            <p class="award-year">{{ award.year }}</p>
            <p class="award-description">{{ award.description }}</p>
          </div>
        </div>
      </div>

      <!-- Contacts Page -->
      <div v-if="currentView === 'contacts'" class="page contacts-page">
        <div class="page-header">
          <h1 class="page-title contacts-title">КОНТАКТЫ</h1>
          <div class="page-line contacts-line"></div>
          <p class="page-subtitle">Свяжитесь с REMATCH FC</p>
        </div>

        <div class="contacts-content">
          <div class="contact-info">
            <h2 class="contact-section-title">Контактная информация</h2>
            <div class="contact-items">
              <div class="contact-item">
                <span class="contact-icon">📍</span>
                <span class="contact-text">г. Москва, ул. Футбольная, 1</span>
              </div>
              <div class="contact-item">
                <span class="contact-icon">📞</span>
                <span class="contact-text">+7 (495) 123-45-67</span>
              </div>
              <div class="contact-item">
                <span class="contact-icon">✉️</span>
                <span class="contact-text">info@rematchfc.ru</span>
              </div>
              <div class="contact-item">
                <span class="contact-icon">🌐</span>
                <span class="contact-text">www.rematchfc.ru</span>
              </div>
            </div>

            <div class="social-section">
              <h3 class="social-title">Социальные сети</h3>
              <div class="social-links">
                <div class="social-link vk">VK</div>
                <div class="social-link telegram">TG</div>
                <div class="social-link youtube">YT</div>
              </div>
            </div>
          </div>

          <div class="contact-form">
            <h2 class="contact-section-title">Написать нам</h2>
            <form @submit.prevent="submitForm" class="form">
              <input v-model="form.name" type="text" placeholder="Ваше имя" class="form-input" />
              <input v-model="form.email" type="email" placeholder="Email" class="form-input" />
              <textarea
                v-model="form.message"
                placeholder="Сообщение"
                rows="4"
                class="form-textarea"
              ></textarea>
              <button type="submit" class="form-submit">Отправить сообщение</button>
            </form>
          </div>
        </div>
      </div>

      <!-- Sponsorship Page -->
      <div v-if="currentView === 'sponsorship'" class="page sponsorship-page">
        <div class="page-header">
          <h1 class="page-title sponsorship-title">СПОНСОРСТВО</h1>
          <div class="page-line sponsorship-line"></div>
          <p class="page-subtitle">Станьте частью легенды REMATCH FC</p>
        </div>

        <div class="sponsorship-content">
          <div class="why-section">
            <h2 class="why-title">Почему REMATCH FC?</h2>
            <div class="why-grid">
              <div class="why-item">
                <div class="why-icon">🏆</div>
                <h3 class="why-item-title">Успех</h3>
                <p class="why-item-text">Множество побед и титулов</p>
              </div>
              <div class="why-item">
                <div class="why-icon">👥</div>
                <h3 class="why-item-title">Аудитория</h3>
                <p class="why-item-text">Миллионы фанатов по всему миру</p>
              </div>
              <div class="why-item">
                <div class="why-icon">⚡</div>
                <h3 class="why-item-title">Инновации</h3>
                <p class="why-item-text">Современный подход к футболу</p>
              </div>
            </div>
          </div>

          <div class="packages-section">
            <div class="package-card champion">
              <h3 class="package-title">Пакет "Чемпион"</h3>
              <ul class="package-features">
                <li>• Логотип на форме команды</li>
                <li>• Реклама на стадионе</li>
                <li>• Упоминание в соцсетях</li>
                <li>• VIP места на матчах</li>
              </ul>
              <div class="package-price">от 500,000₽</div>
            </div>

            <div class="package-card legend">
              <h3 class="package-title">Пакет "Легенда"</h3>
              <ul class="package-features">
                <li>• Все из пакета "Чемпион"</li>
                <li>• Название стадиона</li>
                <li>• Эксклюзивные мероприятия</li>
                <li>• Персональный менеджер</li>
              </ul>
              <div class="package-price">от 2,000,000₽</div>
            </div>
          </div>

          <div class="sponsor-cta">
            <button @click="contactSponsor" class="sponsor-btn">Стать спонсором</button>
          </div>
        </div>
      </div>

      <!-- Player Detail Page -->
      <div v-if="currentView === 'player' && selectedPlayer" class="page player-detail-page">
        <div class="fifa-card">
          <div class="fifa-header">
            <span class="fifa-club">REMATCH FC</span>
          </div>

          <div class="fifa-rating">{{ selectedPlayer.rating }}</div>

          <div class="fifa-player">
            <div class="fifa-avatar">⚽</div>
            <h2 class="fifa-name">{{ selectedPlayer.name }}</h2>
            <p class="fifa-position">{{ selectedPlayer.position }}</p>
          </div>

          <div class="fifa-basic-stats">
            <div class="fifa-stat">
              <span class="fifa-stat-label">ВОЗРАСТ</span>
              <span class="fifa-stat-value">{{ selectedPlayer.age }}</span>
            </div>
            <div class="fifa-stat">
              <span class="fifa-stat-label">НОМЕР</span>
              <span class="fifa-stat-value">{{ selectedPlayer.number }}</span>
            </div>
          </div>

          <div class="fifa-detailed-stats">
            <div v-for="stat in selectedPlayer.stats" :key="stat.name" class="fifa-stat-row">
              <span class="fifa-stat-name">{{ stat.name }}</span>
              <div class="fifa-stat-bar">
                <div class="fifa-stat-fill" :style="{ width: stat.value + '%' }"></div>
              </div>
              <span class="fifa-stat-number">{{ stat.value }}</span>
            </div>
          </div>

          <div class="fifa-info">
            <h3 class="fifa-info-title">ИНФОРМАЦИЯ</h3>
            <p class="fifa-info-text">{{ selectedPlayer.description }}</p>
          </div>

          <button @click="goBack" class="fifa-back-btn">← Назад к команде</button>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const currentView = ref('home')
const selectedPlayer = ref(null)
const mobileMenuOpen = ref(false)

const form = ref({
  name: '',
  email: '',
  message: '',
})

const navItems = ref([
  { id: 'home', name: 'Главная' },
  { id: 'about', name: 'О нас' },
  { id: 'awards', name: 'Награды' },
  { id: 'contacts', name: 'Контакты' },
  { id: 'sponsorship', name: 'Спонсорство' },
])

const players = ref([
  {
    id: 1,
    name: 'Денис Сафронов',
    position: 'Нападающий',
    age: 24,
    number: 9,
    rating: 87,
    goals: 156,
    matches: 203,
    description:
      'Быстрый и техничный нападающий с отличным чувством гола. Лидер атакующих действий команды.',
    biography:
      'Денис Сафронов - легенда современного футбола, чья карьера началась в небольшом городке под Санкт-Петербургом. В 16 лет он был замечен скаутами REMATCH FC во время любительского турнира, где забил невероятный гол с 35 метров. Его скорость и техника поразили всех присутствующих. За 8 лет в команде Денис стал настоящим символом клуба, забив более 150 голов и приведя команду к трем чемпионским титулам. Его коронный прием - "молниеносный рывок Сафронова" - стал визитной карточкой REMATCH FC. Денис известен своей преданностью команде и невероятной работоспособностью на тренировках.',
    stats: [
      { name: 'Скорость', value: 92 },
      { name: 'Удар', value: 88 },
      { name: 'Дриблинг', value: 85 },
      { name: 'Пас', value: 78 },
      { name: 'Защита', value: 45 },
      { name: 'Физика', value: 82 },
    ],
  },
  {
    id: 2,
    name: 'Никита Кузнецов',
    position: 'Полузащитник',
    age: 26,
    number: 8,
    rating: 85,
    goals: 89,
    matches: 267,
    description:
      'Универсальный полузащитник с отличным видением поля и точными передачами. Мозг команды.',
    biography:
      'Никита Кузнецов - стратегический гений REMATCH FC, прозванный фанатами "Профессором". Выпускник футбольной академии, он обладает уникальным видением игры и способностью читать матч на несколько ходов вперед. В 19 лет Никита дебютировал в основном составе и сразу же стал незаменимым игроком. Его точность передач составляет 94%, что является рекордом лиги. Кузнецов известен своими дальними передачами, которые часто приводят к голевым моментам. Он также является автором тактических схем, которые помогли команде выиграть Кубок Европы. Никита - интеллектуал футбола, изучающий игру противников до мельчайших деталей.',
    stats: [
      { name: 'Скорость', value: 78 },
      { name: 'Удар', value: 82 },
      { name: 'Дриблинг', value: 88 },
      { name: 'Пас', value: 94 },
      { name: 'Защита', value: 75 },
      { name: 'Физика', value: 80 },
    ],
  },
  {
    id: 3,
    name: 'Антон Аппанов',
    position: 'Защитник',
    age: 28,
    number: 4,
    rating: 83,
    goals: 23,
    matches: 312,
    description: 'Надежный центральный защитник с отличной игрой головой. Капитан команды.',
    biography:
      'Антон Аппанов - несокрушимая стена REMATCH FC и капитан команды уже 5 лет. Его путь в футболе начался в детской команде, где он играл нападающим, но тренер заметил его исключительные оборонительные качества. Антон обладает уникальной способностью предугадывать действия нападающих и всегда находится в нужном месте в нужное время. За свою карьеру он провел более 300 матчей, пропустив всего 89 голов - невероятный показатель для защитника. Аппанов известен своим лидерством на поле и способностью мотивировать команду в самые сложные моменты. Его коронная фраза "Через меня не пройдут!" стала девизом всей обороны REMATCH FC.',
    stats: [
      { name: 'Скорость', value: 72 },
      { name: 'Удар', value: 65 },
      { name: 'Дриблинг', value: 70 },
      { name: 'Пас', value: 85 },
      { name: 'Защита', value: 92 },
      { name: 'Физика', value: 90 },
    ],
  },
  {
    id: 4,
    name: 'Денис Щегольков',
    position: 'Вратарь',
    age: 25,
    number: 1,
    rating: 84,
    goals: 2,
    matches: 189,
    description: 'Молодой перспективный вратарь с отличной реакцией и уверенной игрой на выходах.',
    biography:
      'Денис Щегольков - "Человек-паук" REMATCH FC, чьи невероятные сейвы стали легендой. Его карьера началась драматично: в 17 лет он заменил травмированного основного вратаря в финале юношеского чемпионата и отбил решающий пенальти. С тех пор Денис стал неотъемлемой частью команды. Его рекорд - 23 матча подряд без пропущенных голов - до сих пор не побит в лиге. Щегольков известен своими акробатическими сейвами и умением играть ногами, часто начиная атаки команды точными передачами. Он также забил 2 гола со штрафных ударов, что делает его уникальным вратарем. Денис изучает психологию нападающих и часто угадывает направление ударов.',
    stats: [
      { name: 'Рефлексы', value: 89 },
      { name: 'Позиционирование', value: 86 },
      { name: 'Обработка мяча', value: 88 },
      { name: 'Удар ногой', value: 75 },
      { name: 'Броски', value: 87 },
      { name: 'Физика', value: 83 },
    ],
  },
  {
    id: 5,
    name: 'Дмитрий Тишинков',
    position: 'Крайний защитник',
    age: 23,
    number: 3,
    rating: 81,
    goals: 34,
    matches: 156,
    description: 'Быстрый крайний защитник с хорошими навыками в атаке. Молодая звезда команды.',
    biography:
      'Дмитрий Тишинков - восходящая звезда REMATCH FC, прозванный "Ракетой" за свою невероятную скорость. В 18 лет он установил рекорд клуба, пробежав 100 метров за 10.8 секунды во время тренировки. Дмитрий уникален тем, что одинаково хорошо играет в обороне и атаке, часто подключаясь к атакующим действиям и забивая важные голы. Его фирменный прием - рывок по флангу с последующим точным навесом - принес команде множество голов. Несмотря на молодость, Тишинков уже стал ключевым игроком и считается будущим капитаном команды. Он известен своей скромностью и постоянным стремлением к совершенствованию, проводя дополнительные тренировки после основных занятий.',
    stats: [
      { name: 'Скорость', value: 90 },
      { name: 'Удар', value: 74 },
      { name: 'Дриблинг', value: 82 },
      { name: 'Пас', value: 80 },
      { name: 'Защита', value: 84 },
      { name: 'Физика', value: 78 },
    ],
  },
])

const awards = ref([
  {
    id: 1,
    icon: '🏆',
    title: 'Чемпион Лиги',
    year: '2023',
    description: 'Первое место в национальном чемпионате',
  },
  {
    id: 2,
    icon: '🥇',
    title: 'Кубок Европы',
    year: '2022',
    description: 'Победа в престижном европейском турнире',
  },
  {
    id: 3,
    icon: '⚽',
    title: 'Лучший клуб года',
    year: '2023',
    description: 'Награда от Федерации футбола',
  },
  {
    id: 4,
    icon: '🌟',
    title: 'Суперкубок',
    year: '2022',
    description: 'Победа над чемпионом кубка',
  },
  {
    id: 5,
    icon: '🎖️',
    title: 'Кубок Легенд',
    year: '2021',
    description: 'Турнир среди исторических команд',
  },
  {
    id: 6,
    icon: '🏅',
    title: 'Приз Fair Play',
    year: '2023',
    description: 'За честную игру и спортивность',
  },
])

const navigateTo = (view) => {
  currentView.value = view
  mobileMenuOpen.value = false
}

const selectPlayer = (player) => {
  selectedPlayer.value = player
  currentView.value = 'player'
}

const goBack = () => {
  currentView.value = 'home'
  selectedPlayer.value = null
}

const submitForm = () => {
  console.log('Form submitted:', form.value)
  alert('Сообщение отправлено!')
  form.value = { name: '', email: '', message: '' }
}

const contactSponsor = () => {
  alert('Спасибо за интерес! Наш менеджер свяжется с вами в ближайшее время.')
}
</script>

<style lang="scss" scoped>
// Variables
$primary-gradient: linear-gradient(135deg, #00d4ff, #9c27b0);
$secondary-gradient: linear-gradient(135deg, #ff6b35, #f7931e);
$dark-bg: linear-gradient(135deg, #0f172a, #581c87, #0f172a);
$card-bg: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.9));
$text-primary: #ffffff;
$text-secondary: #cbd5e1;
$text-accent: #00d4ff;
$border-color: rgba(156, 39, 176, 0.3);
$hover-border: rgba(0, 212, 255, 0.5);

// Mixins
@mixin flex-center {
  display: flex;
  align-items: center;
  justify-content: center;
}

@mixin card-hover {
  transition: all 0.3s ease;
  &:hover {
    transform: scale(1.05);
    box-shadow: 0 20px 40px rgba(156, 39, 176, 0.2);
  }
}

@mixin gradient-text($gradient) {
  background: $gradient;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

// Base Styles
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.app {
  width: 100vw;
  min-height: 100vh;
  background: $dark-bg;
  font-family: 'Arial', sans-serif;
  color: $text-primary;
}

// Navigation
.navbar {
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid $border-color;
  position: sticky;
  top: 0;
  z-index: 1000;
}

.nav-container {
  max-width: 100%;
  margin: 0 auto;
  padding: 0 1rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 4rem;
}

.nav-logo {
  @include flex-center;
  gap: 0.75rem;
  cursor: pointer;

  .logo-icon {
    width: 2.5rem;
    height: 2.5rem;
    background: $primary-gradient;
    border-radius: 50%;
    @include flex-center;
    color: #000;
    font-weight: bold;
    font-size: 1.2rem;
  }

  .logo-text {
    font-size: 1.5rem;
    font-weight: bold;
    @include gradient-text($primary-gradient);
  }
}

.nav-links {
  display: flex;
  gap: 2rem;

  @media (max-width: 768px) {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.95);
    flex-direction: column;
    padding: 1rem;
    transform: translateY(-100%);
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;

    &.nav-open {
      transform: translateY(0);
      opacity: 1;
      visibility: visible;
    }
  }
}

.nav-link {
  background: none;
  border: none;
  color: $text-secondary;
  font-weight: 600;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    color: $text-primary;
    background: rgba(255, 255, 255, 0.1);
  }

  &.active {
    background: $primary-gradient;
    color: $text-primary;
  }
}

.mobile-menu-btn {
  display: none;
  background: none;
  border: none;
  color: $text-primary;
  font-size: 1.5rem;
  cursor: pointer;

  @media (max-width: 768px) {
    display: block;
  }
}

// Main Content
.main-content {
  max-width: 100%;
  margin: 0 auto;
  padding: 2rem 1rem;
}

.page {
  animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

// Page Headers
.hero-section,
.page-header {
  text-align: center;
  margin-bottom: 3rem;
}

.hero-title,
.page-title {
  font-size: 4rem;
  font-weight: bold;
  margin-bottom: 1rem;
  @include gradient-text($primary-gradient);

  @media (max-width: 768px) {
    font-size: 2.5rem;
  }
}

.awards-title {
  @include gradient-text($secondary-gradient);
}

.contacts-title {
  @include gradient-text(linear-gradient(135deg, #10b981, #3b82f6));
}

.sponsorship-title {
  @include gradient-text(linear-gradient(135deg, #a855f7, #ec4899));
}

.hero-line,
.page-line {
  width: 8rem;
  height: 0.25rem;
  background: $primary-gradient;
  margin: 0 auto 1.5rem;
}

.awards-line {
  background: $secondary-gradient;
}

.contacts-line {
  background: linear-gradient(135deg, #10b981, #3b82f6);
}

.sponsorship-line {
  background: linear-gradient(135deg, #a855f7, #ec4899);
}

.hero-subtitle,
.page-subtitle {
  font-size: 1.25rem;
  color: $text-secondary;
  max-width: 48rem;
  margin: 0 auto;
}

// Players Grid
.players-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 75rem;
  margin: 0 auto;
}

.player-card {
  position: relative;
  background: $card-bg;
  border-radius: 1rem;
  padding: 1.5rem;
  border: 1px solid $border-color;
  cursor: pointer;
  @include card-hover;
  overflow: hidden;

  .card-glow {
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, rgba(0, 212, 255, 0.2), transparent);
    opacity: 0;
    transition: opacity 0.3s ease;
    border-radius: 1rem;
  }

  &:hover {
    border-color: $hover-border;

    .card-glow {
      opacity: 1;
    }
  }
}

.player-image {
  position: relative;
  margin-bottom: 1rem;

  .player-avatar {
    width: 100%;
    height: 12rem;
    background: linear-gradient(135deg, #9c27b0, #00d4ff);
    border-radius: 0.75rem;
    @include flex-center;
    font-size: 4rem;
  }

  .player-rating {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    background: $secondary-gradient;
    color: #000;
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    font-size: 0.875rem;
    font-weight: bold;
  }
}

.player-info {
  text-align: center;

  .player-name {
    font-size: 1.5rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
  }

  .player-position {
    color: $text-accent;
    font-weight: 600;
    margin-bottom: 0.5rem;
  }

  .player-stats {
    display: flex;
    justify-content: center;
    gap: 1rem;
    font-size: 0.875rem;
    color: $text-secondary;
  }
}

// Biography Section
.biography-section {
  display: flex;
  flex-direction: column;
  gap: 3rem;
  max-width: 64rem;
  margin: 0 auto;
}

.biography-card {
  background: $card-bg;
  border-radius: 1rem;
  padding: 2rem;
  border: 1px solid $border-color;
  display: flex;
  gap: 2rem;
  align-items: flex-start;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
}

.bio-avatar {
  flex-shrink: 0;
  position: relative;

  .bio-image {
    width: 8rem;
    height: 8rem;
    background: linear-gradient(135deg, #00d4ff, #a855f7);
    border-radius: 50%;
    @include flex-center;
    font-size: 4rem;
  }

  .bio-rating {
    position: absolute;
    bottom: -0.5rem;
    left: 50%;
    transform: translateX(-50%);
    background: $secondary-gradient;
    color: #000;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: bold;
  }
}

.bio-content {
  flex: 1;

  .bio-name {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
  }

  .bio-position {
    color: $text-accent;
    font-weight: 600;
    font-size: 1.125rem;
    margin-bottom: 1rem;
  }

  .bio-text {
    color: $text-secondary;
    line-height: 1.6;
    margin-bottom: 1.5rem;
  }
}

.bio-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 1rem;
}

.stat-item {
  background: rgba(0, 0, 0, 0.3);
  border-radius: 0.5rem;
  padding: 0.75rem;
  text-align: center;

  .stat-label {
    display: block;
    color: #fbbf24;
    font-size: 0.75rem;
    font-weight: 600;
    margin-bottom: 0.25rem;
  }

  .stat-value {
    display: block;
    font-size: 1.125rem;
    font-weight: bold;
  }
}

// Awards Grid
.awards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  max-width: 75rem;
  margin: 0 auto;
}

.award-card {
  background: linear-gradient(135deg, rgba(251, 191, 36, 0.2), rgba(245, 158, 11, 0.2));
  border-radius: 1rem;
  padding: 1.5rem;
  border: 1px solid rgba(251, 191, 36, 0.3);
  text-align: center;
  @include card-hover;

  .award-icon {
    font-size: 4rem;
    margin-bottom: 1rem;
  }

  .award-title {
    font-size: 1.5rem;
    font-weight: bold;
    color: #fbbf24;
    margin-bottom: 0.5rem;
  }

  .award-year {
    color: #f59e0b;
    font-weight: 600;
    margin-bottom: 0.75rem;
  }

  .award-description {
    color: $text-secondary;
  }
}

// Contacts Page
.contacts-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 2rem;
  max-width: 64rem;
  margin: 0 auto;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
}

.contact-info,
.contact-form {
  background: $card-bg;
  border-radius: 1rem;
  padding: 2rem;
  border: 1px solid rgba(16, 185, 129, 0.3);
}

.contact-section-title {
  font-size: 1.5rem;
  font-weight: bold;
  color: #10b981;
  margin-bottom: 1.5rem;
}

.contact-items {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 2rem;
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;

  .contact-icon {
    font-size: 1.25rem;
    color: #10b981;
  }

  .contact-text {
    color: $text-secondary;
  }
}

.social-section {
  .social-title {
    font-size: 1.25rem;
    font-weight: bold;
    color: #10b981;
    margin-bottom: 1rem;
  }

  .social-links {
    display: flex;
    gap: 1rem;
  }

  .social-link {
    width: 2.5rem;
    height: 2.5rem;
    border-radius: 50%;
    @include flex-center;
    color: $text-primary;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;

    &.vk {
      background: #4c75a3;
      &:hover {
        background: #5a87ba;
      }
    }

    &.telegram {
      background: #0088cc;
      &:hover {
        background: #0099dd;
      }
    }

    &.youtube {
      background: #ff0000;
      &:hover {
        background: #ff1a1a;
      }
    }
  }
}

// Form Styles
.form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-input,
.form-textarea {
  width: 100%;
  padding: 0.75rem 1rem;
  background: #334155;
  border: 1px solid #475569;
  border-radius: 0.5rem;
  color: $text-primary;
  font-size: 1rem;

  &::placeholder {
    color: #94a3b8;
  }

  &:focus {
    outline: none;
    border-color: #10b981;
  }
}

.form-submit {
  width: 100%;
  background: linear-gradient(135deg, #10b981, #3b82f6);
  color: $text-primary;
  font-weight: bold;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 0.5rem;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: linear-gradient(135deg, #059669, #2563eb);
    transform: translateY(-2px);
  }
}

// Sponsorship Page
.sponsorship-content {
  max-width: 75rem;
  margin: 0 auto;
}

.why-section {
  background: $card-bg;
  border-radius: 1rem;
  padding: 2rem;
  border: 1px solid rgba(168, 85, 247, 0.3);
  margin-bottom: 2rem;

  .why-title {
    font-size: 2rem;
    font-weight: bold;
    color: #a855f7;
    text-align: center;
    margin-bottom: 1.5rem;
  }

  .why-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
  }

  .why-item {
    text-align: center;

    .why-icon {
      font-size: 2.5rem;
      margin-bottom: 1rem;
    }

    .why-item-title {
      font-size: 1.25rem;
      font-weight: bold;
      margin-bottom: 0.5rem;
    }

    .why-item-text {
      color: $text-secondary;
    }
  }
}

.packages-section {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
}

.package-card {
  border-radius: 1rem;
  padding: 1.5rem;
  border: 1px solid;

  &.champion {
    background: linear-gradient(135deg, rgba(168, 85, 247, 0.2), rgba(236, 72, 153, 0.2));
    border-color: rgba(168, 85, 247, 0.3);

    .package-title {
      color: #a855f7;
    }

    .package-price {
      color: #a855f7;
    }
  }

  &.legend {
    background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(168, 85, 247, 0.2));
    border-color: rgba(236, 72, 153, 0.3);

    .package-title {
      color: #ec4899;
    }

    .package-price {
      color: #ec4899;
    }
  }

  .package-title {
    font-size: 1.5rem;
    font-weight: bold;
    margin-bottom: 1rem;
  }

  .package-features {
    list-style: none;
    margin-bottom: 1.5rem;

    li {
      color: $text-secondary;
      margin-bottom: 0.5rem;
    }
  }

  .package-price {
    font-size: 2rem;
    font-weight: bold;
  }
}

.sponsor-cta {
  text-align: center;
}

.sponsor-btn {
  background: linear-gradient(135deg, #a855f7, #ec4899);
  color: $text-primary;
  font-weight: bold;
  padding: 1rem 2rem;
  border: none;
  border-radius: 0.75rem;
  font-size: 1.125rem;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: linear-gradient(135deg, #9333ea, #db2777);
    transform: scale(1.05);
  }
}

// FIFA Card Styles
.player-detail-page {
  @include flex-center;
  min-height: 80vh;
  padding: 1rem;
}

.fifa-card {
  position: relative;
  background: linear-gradient(135deg, #1e3a8a, #7c3aed, #312e81);
  border-radius: 1.5rem;
  padding: 2rem;
  border: 4px solid #fbbf24;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
  max-width: 28rem;
  width: 100%;
  transition: transform 0.3s ease;

  &:hover {
    transform: scale(1.05);
  }
}

.fifa-header {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4rem;
  background: $secondary-gradient;
  border-radius: 1rem 1rem 0 0;
  @include flex-center;

  .fifa-club {
    color: #000;
    font-weight: bold;
    font-size: 1.125rem;
  }
}

.fifa-rating {
  position: absolute;
  top: 1.5rem;
  right: 1.5rem;
  width: 4rem;
  height: 4rem;
  background: $secondary-gradient;
  border-radius: 50%;
  @include flex-center;
  border: 4px solid $text-primary;
  color: #000;
  font-weight: bold;
  font-size: 1.25rem;
}

.fifa-player {
  margin-top: 3rem;
  margin-bottom: 1.5rem;
  text-align: center;

  .fifa-avatar {
    width: 8rem;
    height: 8rem;
    margin: 0 auto 1rem;
    background: linear-gradient(135deg, #00d4ff, #a855f7);
    border-radius: 50%;
    @include flex-center;
    font-size: 4rem;
  }

  .fifa-name {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
  }

  .fifa-position {
    color: #fbbf24;
    font-weight: 600;
    font-size: 1.125rem;
  }
}

.fifa-basic-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.fifa-stat {
  background: rgba(0, 0, 0, 0.3);
  border-radius: 0.5rem;
  padding: 0.75rem;
  text-align: center;

  .fifa-stat-label {
    display: block;
    color: #fbbf24;
    font-size: 0.875rem;
    font-weight: 600;
    margin-bottom: 0.25rem;
  }

  .fifa-stat-value {
    display: block;
    font-size: 1.25rem;
    font-weight: bold;
  }
}

.fifa-detailed-stats {
  margin-bottom: 1.5rem;
}

.fifa-stat-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;

  .fifa-stat-name {
    color: $text-secondary;
    font-size: 0.875rem;
  }

  .fifa-stat-bar {
    width: 6rem;
    height: 0.5rem;
    background: #374151;
    border-radius: 9999px;
    overflow: hidden;
    margin: 0 0.5rem;

    .fifa-stat-fill {
      height: 100%;
      background: linear-gradient(to right, #10b981, #fbbf24);
      transition: width 0.5s ease;
    }
  }

  .fifa-stat-number {
    color: $text-primary;
    font-size: 0.875rem;
    font-weight: bold;
    width: 2rem;
    text-align: right;
  }
}

.fifa-info {
  background: rgba(0, 0, 0, 0.3);
  border-radius: 0.5rem;
  padding: 1rem;
  margin-bottom: 1.5rem;

  .fifa-info-title {
    color: #fbbf24;
    font-weight: 600;
    margin-bottom: 0.5rem;
  }

  .fifa-info-text {
    color: $text-secondary;
    font-size: 0.875rem;
  }
}

.fifa-back-btn {
  width: 100%;
  background: linear-gradient(135deg, #00d4ff, #a855f7);
  color: $text-primary;
  font-weight: bold;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 0.75rem;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: linear-gradient(135deg, #0ea5e9, #9333ea);
    transform: scale(1.05);
  }
}

// Responsive Design
@media (max-width: 768px) {
  .main-content {
    padding: 1rem;
  }

  .players-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }

  .biography-card {
    padding: 1rem;
  }

  .contacts-content {
    grid-template-columns: 1fr;
  }

  .packages-section {
    grid-template-columns: 1fr;
  }

  .fifa-card {
    padding: 1.5rem;
  }
}
</style>
